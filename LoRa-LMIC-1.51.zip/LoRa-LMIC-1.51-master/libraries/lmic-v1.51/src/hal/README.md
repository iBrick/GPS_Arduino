LMIC-v1.5 library
=========================

Note in hardware support. hal.cpp contains conditional sections for separate hardware architectures. 
As these architectures are known at compile time, the hal.cpp can be used both for AVR (Atmega)
and ESP8266 types of mcu

